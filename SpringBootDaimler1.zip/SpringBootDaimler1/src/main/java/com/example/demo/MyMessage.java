package com.example.demo;
import org.springframework.stereotype.Component;
//ctrl+shift+O
@Component("msg")
public class MyMessage 
{
public void welcome()
{
	System.out.println("Welcome to SpringBoot");
}
public int sum(int a,int b)
{
	return a+b;
}
}
