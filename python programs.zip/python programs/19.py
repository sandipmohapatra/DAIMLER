i = 0;  
while i!=10:  
    print("%d"%i);  
    continue;  
    i=i+1;  
