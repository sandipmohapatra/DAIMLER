i=1; #initializing a local variable  
#starting a loop from 1 to 10  
for i in range(1,11):  
    if i==5:  
        continue;  
    print("%d"%i);  
