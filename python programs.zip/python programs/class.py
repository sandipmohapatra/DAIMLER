class Employee:  
    id = 10;  
    name = "John"  
    def display (self):  
        print("ID: %d \nName: %s"%(self.id,self.name))  
emp = Employee()  
emp.display() 
