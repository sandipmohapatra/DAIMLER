i=1  
n=int(input("Enter the number up to which you want to print the natural numbers?"))  
for i in range(0,10):  
    print(i,end = ' ')  
