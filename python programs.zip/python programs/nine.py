i=1;  
num = int(input("Enter a number:"));  
for i in range(1,11):  
    print("%d X %d = %d"%(num,i,num*i));  
