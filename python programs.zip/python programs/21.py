str = "Hello"   
str1 = " world"  
print(str*3) # prints HelloHelloHello  
print(str+str1)# prints Hello world   
print(str[4]) # prints o              
print(str[2:4]); # prints ll           
