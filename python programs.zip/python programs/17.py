i = 0;  
while 1:  
    print(i," ",end=""),  
    i=i+1;  
    if i == 10:  
        break;  
print("came out of while loop");  
