i=1  
number=0  
b=9  
number = int(input("Enter the number?"))  
while i<=10:  
    print("%d X %d = %d \n"%(number,i,number*i));  
    i = i+1;  
