for i in range(0,5):  
    print(i)  
    break;  
else:print("for loop is exhausted");  
print("The loop is broken due to break statement...came out of loop")  
