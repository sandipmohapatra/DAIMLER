print('welcome to python programming at microland')
