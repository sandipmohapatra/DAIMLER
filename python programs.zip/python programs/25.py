#defining the function  
def change_string (str):  
    str = str + " Hows you";  
    print("printing the string inside function :",str);  
  
string1 = "Hi I am there"  
  
#calling the function  
change_string(string1)  
  
print("printing the string outside function :",string1)  
