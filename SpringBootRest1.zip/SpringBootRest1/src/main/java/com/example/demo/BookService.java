package com.example.demo;
import java.util.*;
import org.springframework.stereotype.Component;
@Component
public class BookService implements IBookService
{
	private static List<Book> books = new ArrayList<Book>();
	static
	{
	Book book1=new Book(1,"Core Java",300.00, "Shubham");
	Book book2=new Book(2,"Adv Java",600.00, "Trupti");
	Book book3=new Book(3,"Spring Boot",700.00, "Madhu");
	books.add(book1);
	books.add(book2);
	books.add(book3);
		}
	public void addBook(Book book)
	{
	books.add(book);	 
		}

	public void editBook(Book book, int bookid) 
	{
	Book record=getBookById(bookid); 
		books.remove(record);
		book.setBookid(bookid);
		books.add(book);
	}

	public boolean deleteBook(int bookid) {
	 Book record =getBookById(bookid);
	 books.remove(record);
		return Boolean.TRUE;
	}

	public Book getBookById(int bookid) 
	{
			return books.stream().filter(b ->b.getBookid() == bookid).findFirst().get();
	}

	public List<Book> getAllBook()
	{
		return books;
	}

}