package in.nareshit.raghu.runner;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.util.EmailUtil;

@Component
public class MailTestRunner implements CommandLineRunner {
	@Autowired
	private EmailUtil util;
	
	@Override
	public void run(String... args) throws Exception {
		//FileSystemResource file = new FileSystemResource("F:\\Images\\SpringBoot9AM_04092020.png");
		FileSystemResource file = new FileSystemResource("C:\\STS WORKSPACE\\SpringMail\\login.txt");
		boolean sent = util.send("sandipmohapatra2016@gmail.com", 
				new String[] {
						"sandip7760213015@gmail.com"
												}, 
				new String[] {
						"sandipmohapatra2022@gmail.com"
								}, 
				"HELLO USER!!", 
				"<html><body><h3>WELCOME TO EMAIL TEST :" +new Date() 
				+"</h3> <b>Sandip</b> <i>HELLO DIAMLER STUDENTS</i>"
				+"</body></html>", 
				file);
		if(sent) {
			System.out.println("SUCCESS");
		} else {
			System.out.println("FAILED");
		}
	}
}
