package in.nareshit.raghu.util;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class EmailUtil {
	@Autowired
	private JavaMailSender sender; //HAS-A

	public boolean send(
			String to,
			String cc[],
			String bcc[],
			String subject,
			String text,
			Resource file
			) 
	{
		boolean flag = false;
		try {
			//1. create empty message object
			MimeMessage message = sender.createMimeMessage();
			
			//2. provide data to message
			// true -> attachment exist, false-> attachment not exist
			// if file exist (not null) then true else false
			MimeMessageHelper helper = new MimeMessageHelper(message, file!=null?true:false);
			
			//3. set data
			helper.setTo(to);
			if(cc!=null && cc.length>0)
				helper.setCc(cc);
			if(bcc!=null && bcc.length>0)
				helper.setBcc(bcc);
			
			helper.setSubject(subject);
			
			//helper.setText(text);
			helper.setText(text,true);
			
			if(file!=null)
				helper.addAttachment(file.getFilename(), file);
			
			//4. send email
			sender.send(message);
			
			flag = true;
		} catch (MessagingException e) {
			flag = false;
			e.printStackTrace();
		}

		return flag;
	}
	
	//overloaded methods
	public boolean send(
			String to,		
			String subject,
			String text)
	{
		return send(to, null, null, subject, text, null);
	}
		
}